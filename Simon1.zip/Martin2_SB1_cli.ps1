#Param (
#        [string]$identity_code = $null,
#        [string]$site_id = $null,
#        [string]$report_id = $null, 
#    [int]$debuglevel = 0
#)
function getReportUrl([String]$identity_code,[String]$site_id,[String]$report_id){
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json")
    $headers.Add("Authorization", "Token "+$identity_code)
    
    $body = "{`"query`":`"{`\n  site(id: `\`""+$site_id+"`\`") {`\n    id`\n    name`\n    reportExecutionResults(reportId: `\`""+$report_id+"`\`") {`\n      url`\n    }`\n  }`\n}`",`"variables`":{}}"
    
    $response = Invoke-RestMethod 'https://api.lansweeper.com/api/v2/graphql' -Method 'POST' -Headers $headers -Body $body
    $response | ConvertTo-Json -Depth 9   
    $response
}

function getReportData([String]$URL){
    $response = Invoke-RestMethod -Uri $URL
    #Write-Host $response
    #$data = $response.Split([Environment]::NewLine)
    $data = $response.Split("`n")
    $numberoflines = $data.length
    $numberoflines
}

#elseif ($args.Count -eq 3) {
#	Write-Host "Found a three arguments. Trying to get number of lines in the report."
    $url= getReportUrl $args[0] $args[1] $args[2]
    $url = $url.data.site.reportExecutionResults.url
    $lines=getReportData $url
#    $lines=[int].lines

#write-host $lines.GetType().name

Write-Host 
"<prtg>"
    "<result>"
        "<channel>" + ' Count' + "</channel>"
        "<value>"+ $lines +"</value>"
    "</result>"
"</prtg>"